
import cv2
import os
import numpy as np

input_folder = "images"
output_folder = "results"

os.makedirs(output_folder, exist_ok=True)

for filename in os.listdir(input_folder):
    if filename.endswith(".png"):
        img_path = os.path.join(input_folder, filename)
        image = cv2.imread(img_path, 0)

        # Apply Gaussian Blur for denoising
        denoised = cv2.GaussianBlur(image, (5, 5), 0)

        save_path = os.path.join(output_folder, "denoised_" + filename)
        cv2.imwrite(save_path, denoised)

print("Denoising completed. Check results folder.")
