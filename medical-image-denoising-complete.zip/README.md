
# Medical Image Denoising Project

## 📌 Overview
This project demonstrates denoising of medical-like X-ray/MRI scan images using Gaussian filtering.

## 📂 Project Structure
- images/ → Contains noisy input images
- results/ → Contains denoised output images
- main.py → Main processing script
- requirements.txt → Required libraries

## 🛠 Technologies Used
- Python
- OpenCV
- NumPy
- Matplotlib

## ▶️ How to Run

1. Install dependencies:
   pip install -r requirements.txt

2. Run the program:
   python main.py

3. Check the 'results' folder for output images.

## 🎯 Objective
To improve image clarity by removing Gaussian noise from medical scans.
